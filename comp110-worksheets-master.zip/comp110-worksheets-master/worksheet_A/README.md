# COMP110 Worksheet A: SpaceChem

Please upload the screenshots of your SpaceChem circuits to this directory.

Please also edit this file (`README.md`) to include a link to your YouTube playlist.

https://www.youtube.com/playlist?list=PLN80s9Qm7pzjlwWYqb3MMyDj1fU7YUwk5
